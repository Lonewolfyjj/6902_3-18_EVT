#!/bin/bash
DOCKER_PROJECT="rk2108d_build"
user=$(whoami)
isDockerRunning=$(docker container ls | $user"_"$DOCKER_PROJECT)
hasDocker=$(docker ps -a | grep $user"_"$DOCKER_PROJECT)
echo $user"_"$DOCKER_PROJECT
if [ "$isDockerRunning" == "" ]; then
  echo "Docker is not running $user Docker"
  if [ "$hasDocker" == "" ]; then
    echo "have no docker name " $user"_"$DOCKER_PROJECT
  else
    echo $user"_"$DOCKER_PROJECT" is already stop, now remove it"
    docker stop $user"_"$DOCKER_PROJECT
    sleep 1
    docker rm $user"_"$DOCKER_PROJECT
  fi
else
  echo "Docker running now it will stop"
  docker stop $user"_"$DOCKER_PROJECT
  sleep 1
  docker rm $user"_"$DOCKER_PROJECT
fi