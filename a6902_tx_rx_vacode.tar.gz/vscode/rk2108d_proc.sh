#!/bin/bash

WORK_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && cd ../ && pwd )""/bsp/rockchip/rk2108"
WORK_DIR_ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && cd ../ && pwd )"
SOURCE="export RTT_EXEC_PATH=/opt/gcc-arm-none-eabi-7-2018-q2-update/bin && git config --global --add safe.directory $WORK_DIR_ROOT && git config --global --add safe.directory $WORK_DIR_ROOT/bsp/rockchip/common/hal"
BUILD_CMD="./build.sh"
DOCKER_CONTAINER_NAME=$(whoami)_rk2108d_build

if [ "$1"_ = "new_config"_ ]; then
  BUILD_ARG=""
  CMD="cd $WORK_DIR && $SOURCE && cp board/audio_demo_rk2108_v11/defconfig .config && scons --menuconfig"
  echo "building new config!!!"
  docker exec -it --user root $DOCKER_CONTAINER_NAME /bin/bash -c "$CMD"
  exit
fi

if [ "$1"_ = "set_config"_ ]; then
  BUILD_ARG=""
  CMD="cd $WORK_DIR && $SOURCE && scons --menuconfig"
  echo "building new config!!!"
  docker exec -it --user root $DOCKER_CONTAINER_NAME /bin/bash -c "$CMD"
  exit
fi

if [ "$1"_ = "build"_ ]; then
  BUILD_ARG=""
  CMD="cd $WORK_DIR && $SOURCE && $BUILD_CMD $BUILD_ARG"
  echo "building project!!!"
  docker exec -i --user root $DOCKER_CONTAINER_NAME /bin/bash -c "$CMD"
  exit
fi

if [ "$1"_ = "clean"_ ]; then
  BUILD_ARG="scons -c"
  CMD="cd $WORK_DIR && $SOURCE && $BUILD_ARG"
  echo "clean build cache!!!"
  docker exec -i --user root $DOCKER_CONTAINER_NAME /bin/bash -c "$CMD"
  exit
fi

if [ "$1"_ = "clean_build"_ ]; then
  BUILD_ARG="scons -c"
  CMD="cd $WORK_DIR && $SOURCE && $BUILD_ARG && $BUILD_CMD"
  echo "clean build cache!!!"
  docker exec -i --user root $DOCKER_CONTAINER_NAME /bin/bash -c "$CMD"
  exit
fi

if [ "$1"_ = "dump_call_stack"_ ]; then
  echo "input all params splite by space of wrong msg in below, then press enter:"
  read user_input_params
  inarr=(${user_input_params})
  # if [ "${inarr[3]}"_ = ""_ ]; then
  #   echo "wrong param num, all param is:" $user_input_params
  #   exit
  # fi
  BUILD_ARG="addr2line -e rtthread.elf -a -f ${inarr[@]}"
  CMD="cd $WORK_DIR && $SOURCE && echo $BUILD_ARG && $BUILD_ARG"
  echo "----------dump call statck-------------------"
  docker exec -i --user root $DOCKER_CONTAINER_NAME /bin/bash -c "$CMD"
  exit
fi

if [ "$1"_ = "save_config_to_tx"_ ]; then
  cp $WORK_DIR/.config $WORK_DIR/board/audio_hollyland_a6902_tx/defconfig
  cp $WORK_DIR/rtconfig.h $WORK_DIR/board/audio_hollyland_a6902_tx/rtconfig.txt
  exit
fi

if [ "$1"_ = "save_config_to_rx"_ ]; then
  cp $WORK_DIR/.config $WORK_DIR/board/audio_hollyland_a6902_rx/defconfig
  cp $WORK_DIR/rtconfig.h $WORK_DIR/board/audio_hollyland_a6902_rx/rtconfig.txt
  exit
fi

