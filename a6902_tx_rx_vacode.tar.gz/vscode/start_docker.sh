#!/bin/bash
DOCKER_PROJECT="rk2108d_build"
DOCKER_IMAGE="ubuntu-rk2108d:18.04"
USER=$(whoami)
IS_DOCKER_RUNNING=$(docker container ls | grep $USER"_"$DOCKER_PROJECT)
HAS_DOCKER=$(docker ps -a | grep $USER"_"$DOCKER_PROJECT)
echo $USER"_"$DOCKER_PROJECT
if [ "$IS_DOCKER_RUNNING" == "" ]; then
  echo "Docker is not running"
  if [ "$HAS_DOCKER" == "" ]; then
    echo "docker name" $USER"_"$DOCKER_PROJECT "not exsist" 
    docker run -itd -v ${HOME}:${HOME} -v /etc/localtime:/etc/localtime --user root --name $USER"_"$DOCKER_PROJECT $DOCKER_IMAGE /bin/bash
  else
  echo "docker name " $USER"_"$DOCKER_PROJECT "start" 
    docker start $USER"_"$DOCKER_PROJECT
  fi
else
  echo "Docker is already running."
fi